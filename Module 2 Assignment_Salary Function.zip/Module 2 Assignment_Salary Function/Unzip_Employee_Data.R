# Load necessary libraries
library(utils)

# Define the zip file and destination folder
zip_file <- "Employee_Profile.zip"
destination_folder <- "Employee_Profile_Unzipped"

# Unzip the file
unzip(zip_file, exdir = destination_folder)

# Load and display the employee CSV file
csv_file <- file.path(destination_folder, "GARY JIMENEZ_details.csv")
employee_data <- read.csv(csv_file)
print(employee_data)
